﻿
using System;

public class NomeeSaudacao
{
    public static void Main(string[] args)
    {
    Console.WriteLine("Digite seu nome:");
    string nome = Console.ReadLine();

    Console.WriteLine($"Olá, {nome}! Seja bem-vindo!");
    }
}